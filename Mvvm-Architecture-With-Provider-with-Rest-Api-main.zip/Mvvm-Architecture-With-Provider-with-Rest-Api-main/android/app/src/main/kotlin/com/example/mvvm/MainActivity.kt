package com.example.mvvm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
