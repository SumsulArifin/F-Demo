

class RoutesName {

  static const String splash = 'splash_view' ;


  //accounts routes name
  static const String login = 'login_screen' ;
  static const String signUp = 'signup_screen' ;

  //home screen routes name
  static const String home = 'home_sceen' ;



}